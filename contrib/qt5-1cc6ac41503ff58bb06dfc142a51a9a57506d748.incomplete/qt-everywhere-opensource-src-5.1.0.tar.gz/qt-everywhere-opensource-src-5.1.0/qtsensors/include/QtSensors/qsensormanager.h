#include "../../src/sensors/qsensormanager.h"

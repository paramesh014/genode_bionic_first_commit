#include "../../src/sensors/qsensorsglobal.h"

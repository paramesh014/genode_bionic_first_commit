#include "../../src/sensors/gestures/qsensorgesturemanager.h"

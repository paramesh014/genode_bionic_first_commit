#include "../../src/sensors/qsensor.h"

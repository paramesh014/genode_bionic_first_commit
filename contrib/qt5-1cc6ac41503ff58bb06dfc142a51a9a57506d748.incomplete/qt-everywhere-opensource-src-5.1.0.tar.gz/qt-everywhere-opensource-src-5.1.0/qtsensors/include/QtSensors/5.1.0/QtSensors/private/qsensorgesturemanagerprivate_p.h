#include "../../../../../src/sensors/gestures/qsensorgesturemanagerprivate_p.h"

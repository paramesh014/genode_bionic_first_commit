#include "../../../../../src/sensors/qmagnetometer_p.h"

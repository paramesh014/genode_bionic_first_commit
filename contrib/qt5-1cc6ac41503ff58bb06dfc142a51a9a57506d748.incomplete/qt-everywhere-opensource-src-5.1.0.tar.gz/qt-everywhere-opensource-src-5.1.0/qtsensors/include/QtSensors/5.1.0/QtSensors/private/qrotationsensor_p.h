#include "../../../../../src/sensors/qrotationsensor_p.h"

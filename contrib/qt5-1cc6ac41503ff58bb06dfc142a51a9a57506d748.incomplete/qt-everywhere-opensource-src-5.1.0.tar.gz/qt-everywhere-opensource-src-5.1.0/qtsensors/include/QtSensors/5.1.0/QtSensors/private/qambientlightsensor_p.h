#include "../../../../../src/sensors/qambientlightsensor_p.h"

#include "../../../../../src/sensors/gestures/qsensorgesture_p.h"

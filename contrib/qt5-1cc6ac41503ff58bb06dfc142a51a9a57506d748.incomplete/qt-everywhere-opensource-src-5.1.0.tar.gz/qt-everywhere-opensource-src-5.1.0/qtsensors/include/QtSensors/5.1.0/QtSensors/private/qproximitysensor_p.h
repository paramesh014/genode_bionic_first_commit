#include "../../../../../src/sensors/qproximitysensor_p.h"

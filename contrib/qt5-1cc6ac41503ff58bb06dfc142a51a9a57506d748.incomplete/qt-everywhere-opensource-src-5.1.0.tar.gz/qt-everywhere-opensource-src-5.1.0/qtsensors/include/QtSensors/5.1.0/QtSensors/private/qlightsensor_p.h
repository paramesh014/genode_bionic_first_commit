#include "../../../../../src/sensors/qlightsensor_p.h"

#include "../../../../../src/sensors/qirproximitysensor_p.h"

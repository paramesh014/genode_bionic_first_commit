#include "../../../../../src/sensors/qcompass_p.h"

#include "../../../../../src/sensors/qambienttemperaturesensor_p.h"

#include "../../src/sensors/qambientlightsensor.h"

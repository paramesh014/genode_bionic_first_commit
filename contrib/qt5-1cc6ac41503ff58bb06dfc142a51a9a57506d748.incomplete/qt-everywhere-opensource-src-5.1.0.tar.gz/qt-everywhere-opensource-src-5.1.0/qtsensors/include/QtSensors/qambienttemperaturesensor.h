#include "../../src/sensors/qambienttemperaturesensor.h"

#include "../../src/sensors/gestures/qsensorgesturerecognizer.h"

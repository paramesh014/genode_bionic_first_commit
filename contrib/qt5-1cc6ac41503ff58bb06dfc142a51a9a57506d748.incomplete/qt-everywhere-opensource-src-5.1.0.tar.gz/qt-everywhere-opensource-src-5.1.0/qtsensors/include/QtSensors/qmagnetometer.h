#include "../../src/sensors/qmagnetometer.h"

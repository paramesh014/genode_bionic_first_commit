#include "../../src/sensors/qproximitysensor.h"

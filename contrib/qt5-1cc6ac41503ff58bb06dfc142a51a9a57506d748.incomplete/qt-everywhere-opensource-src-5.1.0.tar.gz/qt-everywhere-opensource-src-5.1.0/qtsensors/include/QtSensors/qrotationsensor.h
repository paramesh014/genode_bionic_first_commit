#include "../../src/sensors/qrotationsensor.h"

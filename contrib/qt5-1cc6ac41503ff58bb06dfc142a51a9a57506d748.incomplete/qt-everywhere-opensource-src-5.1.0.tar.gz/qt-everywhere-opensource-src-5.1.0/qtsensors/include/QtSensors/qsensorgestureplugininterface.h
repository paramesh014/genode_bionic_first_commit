#include "../../src/sensors/gestures/qsensorgestureplugininterface.h"

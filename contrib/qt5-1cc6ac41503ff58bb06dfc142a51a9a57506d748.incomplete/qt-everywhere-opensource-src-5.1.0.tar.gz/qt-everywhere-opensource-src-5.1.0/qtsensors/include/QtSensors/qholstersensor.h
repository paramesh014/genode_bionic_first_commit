#include "../../src/sensors/qholstersensor.h"

#include "../../src/sensors/qlightsensor.h"

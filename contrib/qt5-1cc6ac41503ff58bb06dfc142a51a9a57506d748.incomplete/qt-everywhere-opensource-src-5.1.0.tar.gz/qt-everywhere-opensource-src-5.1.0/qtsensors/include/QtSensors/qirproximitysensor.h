#include "../../src/sensors/qirproximitysensor.h"

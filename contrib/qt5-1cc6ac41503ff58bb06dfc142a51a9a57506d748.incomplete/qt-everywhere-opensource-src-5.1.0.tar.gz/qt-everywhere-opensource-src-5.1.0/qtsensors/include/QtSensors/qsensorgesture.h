#include "../../src/sensors/gestures/qsensorgesture.h"

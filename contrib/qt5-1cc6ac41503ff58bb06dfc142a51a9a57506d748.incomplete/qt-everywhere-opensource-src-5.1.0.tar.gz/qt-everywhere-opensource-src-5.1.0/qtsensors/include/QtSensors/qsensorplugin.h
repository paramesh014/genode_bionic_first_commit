#include "../../src/sensors/qsensorplugin.h"

#include <sys/cdefs.h>
__FBSDID("$FreeBSD$");

#define type		float
#define	roundit		rintf
#define dtype		long
#define	fn		lrintf

#include "s_lrint.c"

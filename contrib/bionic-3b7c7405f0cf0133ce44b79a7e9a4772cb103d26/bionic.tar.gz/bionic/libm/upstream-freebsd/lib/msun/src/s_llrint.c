#include <sys/cdefs.h>
__FBSDID("$FreeBSD$");

#define type		double
#define	roundit		rint
#define dtype		long long
#define	fn		llrint

#include "s_lrint.c"
